<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <FONT FACE="">
        <link href="../CSS/estilsinici.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="IMATGES/favicon.png" />
        <TITLE>Projecte M07 - UF1</TITLE>
</head>

<body>
    <div class="back"></div>
    <div class="INICI">
        <div class="cuadreinici">
            <div class="cuadreinici_1">
                <h1><?php echo "S'ha creat l'usuari ".$_POST["usuari"]." amb exit! <br>";?></h1>
            </div>
            <?php
                $filename="/var/www/html/ProjectePhP/PHP/usuaris";
                $fitxer=fopen($filename,"a+") or die ("No s'ha pogut fer el registre");
                $user = ($_POST['usuari']);
                $password = ($_POST['ctsnya']);
                $nomcognoms = ($_POST['nomcognoms']);
                $codipostal = ($_POST['codipostal']);
                $email = ($_POST['email']);
                $numcontacte = ($_POST['numcontacte']);
                $visa = ($_POST['visa']);
                $texte="$user:$password:$nomcognoms:$codipostal:$email:$numcontacte:$visa\n";
                if($user && $password && $nomcognoms && $codipostal && $email && $numcontacte && $visa){
                    fwrite($fitxer,$texte);
                    fclose($fitxer);
                }
            ?>
            <form action="http://localhost/ProjectePhP/PHP/iniciuser.php" method="POST">
                <input id="noV" type="user" name="usuari" value="<?php echo "".$user."";?>">
                <input id="noV" type="password" name="ctsnya" value="<?php echo "".$password."";?>">
                <input id="noV" type="user" name="nomcognoms" value="<?php echo "".$nomcognoms."";?>">
                <input id="noV" type="user" name="codipostal" value="<?php echo "".$codipostal."";?>">
                <input id="noV" type="user" name="email" value="<?php echo "".$email."";?>">
                <input id="noV" type="user" name="numcontacte" value="<?php echo "".$numcontacte."";?>">
                <input id="noV" type="user" name="visa" value="<?php echo "".$visa."";?>">
                <br><br>
                <input type="submit" value="ACCEDEIX A LA PAGINA">
		    </form>
        </div>
    </div>
</body>
