<?php
    session_start();
    echo "Nombre de usuario: " . $_SESSION["usuario"];
    $arch="";
    $arch = fopen ("comandes", "w+");
    fwrite($arch, "");
    fclose($arch);
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <FONT FACE="">
        <link href="../CSS/estilsinterficieuser.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="IMATGES/favicon.png" />
        <TITLE>Projecte M07 - UF1</TITLE>
</head>
	<body>
      <div class="back"></div>
      <div class="titol">
		<p class="pinicisessio">LES COMANDES HAN ESTAT ESBORRADES</p>
		<a href="interficieadmin.php" class="botoproser">TORNAR PAGINA PRINCIPAL</a>
	  </div>
    </body>
</html>