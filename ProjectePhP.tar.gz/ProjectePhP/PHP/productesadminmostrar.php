<?php
    session_start();
    echo "Nombre de usuario: " . $_SESSION["usuario"];
    if(($_POST['texto'])){
        $filename="/var/www/html/ProjectePhP/PHP/comandes";
        $fitxer=fopen($filename,"a+") or die ("No s'ha pogut fer el registre de la comanda");
        $textocomanda = ($_POST['texto']);
        $textocomandaescribir="$textocomanda\n";
        fwrite($fitxer,$textocomandaescribir);
        fclose($fitxer);
    }
?>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <FONT FACE="">
        <link href="../CSS/estilsinterficieadmin.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="IMATGES/favicon.png" />
        <TITLE>Projecte M07 - UF1</TITLE>
</head>
	<body>
		<div class="back"></div>
		<nav>
			<a href="interficieadmin.php" class="menu">Pagina Principal</a>
            <a href="productesadmin.php" class="menu">Productes</a>
		    <a href="usuarisadmin.php" class="menu">Usuaris</a>
		    <a href="comandesadmin.php" class="menu">Comandes</a>
		</nav>
        <div class="titolp">
			<h1 id="white">PRODUCTES EN STOCK</h1>
        </div>
        <div class="menuproductes">
            <div class="menuproductes1"><a href="productesadminfootball.php" class="h4"><h4>FOOTBALL</h4><a></div>
            <div class="menuproductes2"><a href="productesadminbasketball.php" class="h4"><h4>BASKETBALL</h4><a></div>
            <div class="menuproductes3"><a href="productesadminaltres.php" class="h4"><h4>ALTRES</h4><a></div>
        </div>
        <div class="indexdivproductes">
            <?php
                $fitxer_productes="/var/www/html/ProjectePhP/PHP/productes";
                $fp=fopen($fitxer_productes,"r") or die ("No s'ha pogut llegir els productes");
                if ($fp) {
                    $mida_fitxer=filesize($fitxer_productes);	
                    $productes = explode(PHP_EOL, fread($fp,$mida_fitxer));
                }
            ?>
            
            <?php 
                foreach ($productes as $producte) {
                    $dadesproducte = explode(":",$producte);
                    $producteid = $dadesproducte[0];
                    $productenom = $dadesproducte[1];
                    $productepreu = $dadesproducte[2];
                    $productetipus = $dadesproducte[3];
                    $texte="$producteid:$productenom:$productepreu:$productetipus\n";

                    $botocomprarya = ('<form action="http://localhost/ProjectePhP/PHP/productesadminmostrar.php" method="POST">
                        <input id="noV" type="text" name="texto" value="'.$texte.'">
                        <input class="comanda" type="submit" name="afegircomanda" value="AFEGEIX A LA COMANDA"></form>');

                    if ($productetipus == "basketball"){
                        echo '<br><br><br><h2>'.$productenom.'</h2><br><p>'.$productepreu.'</p><br><h6><a href="productesadminbasketball.php" class="tipusproducte">'.$productetipus.'</a></h6><br>'.$botocomprarya.'<br><br><br>';
                    }
                    if ($productetipus == "football"){
                        echo '<br><br><br><h2>'.$productenom.'</h2><br><p>'.$productepreu.'</p><br><h6><a href="productesadminfootball.php" class="tipusproducte">'.$productetipus.'</a></h6><br>'.$botocomprarya.'<br><br><br>';
                    }
                    if ($productetipus == "altres"){
                        echo '<br><br><br><h2>'.$productenom.'</h2><br><p>'.$productepreu.'</p><br><h6><a href="productesadminaltres.php" class="tipusproducte">'.$productetipus.'</a></h6><br>'.$botocomprarya.'<br><br><br>';
                    }
                    
                }
                ?>
        </div>
        <div class="usuaricuadre">
			<form action="http://localhost/ProjectePhP/PHP/logoutadmin.php" method="POST">
				<p class="pinicisessio"><?php
				if (!isset($_SESSION["comptador"])) {
					$_SESSION['comptador'] = 1;
					echo "Benvingut " . $_SESSION["usuario"]."<br>";
					echo "Visites web: " . $_SESSION["comptador"] . " durant aquesta sessió.<br>";
					echo "Aquest és el primer accés.<br>";			 
				}	
				else{
					$_SESSION["comptador"] += 1;
					echo "Benvingut " . $_SESSION["usuario"]."<br>";
					echo "Visites web: " . $_SESSION["comptador"] . " durant aquesta sessió.<br>";
					echo "Ultima visita: " . $_SESSION["data_darrer_acces"] . ".<br>";
				}
				date_default_timezone_set('Europe/Andorra');
				$_SESSION['data_darrer_acces'] = date('d/m/Y h:i:s');
			?></p>
				<input id="noV" type="user" name="usuari" value="<?php echo "".session_name()."";?>">
				<input id="noV" type="password" name="ctsnya" value="<?php echo "".$password."";?>">
				<input type="submit" value="LOG OUT">
			</form>
        </div>
        <div class="usuaricuadrecomandes">
            <p class="pinicisessio">PRODUCTES A LA COMANDA:</p>
            <?php
                $fitxer_comandes="/var/www/html/ProjectePhP/PHP/comandes";
                $fc=fopen($fitxer_comandes,"r") or die ("No s'ha pogut llegir les comandes");
                if ($fc) {
                    $mida_fitxerc=filesize($fitxer_comandes);	
                    $comandes = explode(PHP_EOL, fread($fc,$mida_fitxerc));
                }
            ?>
            <?php 
                foreach ($comandes as $productec) {
                    $dadesproductec = explode(":",$productec);
                    $producteidc = $dadesproductec[0];
                    $productenomc = $dadesproductec[1];
                    $productepreuc = $dadesproductec[2];
                    $productetipusc = $dadesproductec[3];
                    echo '<p id="llista" class="pinicisessio">'.$productenomc.' | '.$productepreuc.''; 
                }
                ?>
        </div>
    </body>
</html>