<?php
    session_start();
    echo "Nombre de usuario: " . $_SESSION["usuario"];

    if ($_POST['proid'] && $_POST['pronom'] && $_POST['propreu'] && $_POST['protipus']){
        $filename="/var/www/html/ProjectePhP/PHP/productes";
        $fitxer=fopen($filename,"a+") or die ("No s'ha pogut fer el registre");
        $proid = ($_POST['proid']);
        $pronom = ($_POST['pronom']);
        $propreu = ($_POST['propreu']);
        $protipus = ($_POST['protipus']);
        $texte="$proid:$pronom:$propreu €:$protipus\n";
        fwrite($fitxer,$texte);
        fclose($fitxer);
    }

?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <FONT FACE="">
        <link href="../CSS/estilsinterficieadmin.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="IMATGES/favicon.png" />
        <TITLE>Projecte M07 - UF1</TITLE>
</head>
	<body>
		<div class="back"></div>
		<nav>
			<a href="interficieadmin.php" class="menu">Pagina Principal</a>
            <a href="productesadmin.php" class="menu">Productes</a>
		    <a href="usuarisadmin.php" class="menu">Usuaris</a>
		    <a href="peticionsadmin.php" class="menu">Peticions</a>
		</nav>
        <div class="titolp">
			<h1 id="white">AFEGIR PRODUCTES</h1>
        </div>
        <div class="indexdivproductes">
            <form action="" method="POST">
            <br><p id="white" class="pinicisessio">ID PRODUCTE</p>
                <input type="text" class="num" name="proid" placeholder="ID NUMERIC"><br>
                <p id="white" class="pinicisessio">NOM PRODUCTE</p>
                <input type="text" name="pronom" placeholder="NOM AMB FORMAT: (EQUIP/MARCA - EDICIO)"><br>
                <p id="white" class="pinicisessio">PREU EN €</p>
                <input type="text" class="num" name="propreu" placeholder="PREU"><br>
                <p id="white" class="pinicisessio">TIPUS</p>
                <select name="protipus">
                    <option value="football">FOOTBALL</option>
                    <option value="basketball">BASKETBALL</option>
                    <option value="altres">ALTRES</option>
                </select><br><br>
                <input type="submit" class="comanda" value="AFEGIR"><br><br><br>
            </form>
        </div>
        <div class="usuaricuadre">
			<form action="http://localhost/ProjectePhP/PHP/logoutadmin.php" method="POST">
				<p class="pinicisessio"><?php
				if (!isset($_SESSION["comptador"])) {
					$_SESSION['comptador'] = 1;
					echo "Benvingut " . $_SESSION["usuario"]."<br>";
					echo "Visites web: " . $_SESSION["comptador"] . " durant aquesta sessió.<br>";
					echo "Aquest és el primer accés.<br>";			 
				}	
				else{
					$_SESSION["comptador"] += 1;
					echo "Benvingut " . $_SESSION["usuario"]."<br>";
					echo "Visites web: " . $_SESSION["comptador"] . " durant aquesta sessió.<br>";
					echo "Ultima visita: " . $_SESSION["data_darrer_acces"] . ".<br>";
				}
				date_default_timezone_set('Europe/Andorra');
				$_SESSION['data_darrer_acces'] = date('d/m/Y h:i:s');
			?></p>
				<input id="noV" type="user" name="usuari" value="<?php echo "".session_name()."";?>">
				<input id="noV" type="password" name="ctsnya" value="<?php echo "".$password."";?>">
				<input type="submit" value="LOG OUT">
			</form>
        </div>
    </body>
</html>