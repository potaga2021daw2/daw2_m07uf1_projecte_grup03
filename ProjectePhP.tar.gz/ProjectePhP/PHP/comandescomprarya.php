<?php
    session_start();
    echo "Nombre de usuario: " . $_SESSION["usuario"];?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <FONT FACE="">
        <link href="../CSS/estilsinterficieuser.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="IMATGES/favicon.png" />
        <TITLE>Projecte M07 - UF1</TITLE>
</head>
	<body>
      <div class="back"></div>
      <div class="titol">
		<p class="pinicisessio">Els productes que esta a punt de comprar son:</p>
        <?php
                $fitxer_comandes="/var/www/html/ProjectePhP/PHP/comandes";
                $fp=fopen($fitxer_comandes,"r") or die ("No s'ha pogut llegir les comandes");
                if ($fp) {
                    $mida_fitxer=filesize($fitxer_comandes);	
                    $comandes = explode(PHP_EOL, fread($fp,$mida_fitxer));
                }
            ?>
            <?php 
                foreach ($comandes as $producte) {
                    $dadesproducte = explode(":",$producte);
                    $producteid = $dadesproducte[0];
                    $productenom = $dadesproducte[1];
                    $productepreu = $dadesproducte[2];
                    $productetipus = $dadesproducte[3];
                    echo '<p id="llista" class="pinicisessio">'.$productenom.' | '.$productepreu.''; 
                }
                ?>
		<form action="http://localhost/ProjectePhP/PHP/comandescomprada.php" method="POST">
                <input id="comprarya" type="submit" value="COMPRAR JA">
        </form>
	  </div>
    </body>
</html>